package com.itheima.filter;

import com.alibaba.fastjson.JSONObject;
import com.itheima.pojo.Result;
import com.itheima.utils.JwtUtils;
import lombok.extern.slf4j.Slf4j;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Slf4j
//@WebFilter(filterName = "LoginCheckFilter", urlPatterns = "/*")
public class LoginCheckFilter implements Filter {
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        log.info("LoginCheckFilter...");
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;
        String uri = req.getRequestURI();
        if (uri.contains("/login")) {
            chain.doFilter(req, resp);
        } else {
            String token = req.getHeader("token");
            if (token != null) {
                try {
                    JwtUtils.parseJWT(token);
                    chain.doFilter(req, resp);
                } catch (Exception e) {
                    Result result = Result.error("NOT_LOGIN");
                    String json = JSONObject.toJSONString(result);
                    resp.setContentType("application/json;charset=utf-8");
                    resp.getWriter().write(json);
                }
            } else {
//                resp.sendRedirect(req.getContextPath() + "/login.html");
                Result result = Result.error("NOT_LOGIN");
                String json = JSONObject.toJSONString(result);
                resp.setContentType("application/json;charset=utf-8");
                resp.getWriter().write(json);
            }
        }
    }

}
