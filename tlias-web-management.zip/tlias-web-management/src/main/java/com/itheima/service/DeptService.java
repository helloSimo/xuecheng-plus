package com.itheima.service;

import com.itheima.pojo.Dept;

import java.util.List;

public interface DeptService {
    /**
     * 查询所有部门
     * @return 部门集合
     */
    List<Dept> selectAll();

    /**
     * 根据id删除部门
     * @param id 部门id
     */
    void deleteById(Integer id) throws Exception;

    /**
     * 添加部门
     * @param dept 部门对象
     */
    void add(Dept dept);
}
