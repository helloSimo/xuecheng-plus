package com.itheima.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.itheima.mapper.EmpMapper;
import com.itheima.pojo.Emp;
import com.itheima.pojo.PageBean;
import com.itheima.service.EmpService;
import com.itheima.aop.Log;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

//员工业务实现类
@Slf4j
@Service
public class EmpServiceImpl implements EmpService {
    @Autowired
    private EmpMapper empMapper;

    @Override
    @Log
    public PageBean page(Integer page, Integer pageSize,
                         String name, Short gender,
                         LocalDate begin, LocalDate end){
        PageHelper.startPage(page, pageSize);

        List<Emp> emps = empMapper.list(name, gender, begin, end);
        Page<Emp> pageEmps = (Page<Emp>) emps;
        return new PageBean(pageEmps.getTotal(), pageEmps.getResult());
    }

    @Override
    @Log
    public void delete(List<Integer> ids) {
        empMapper.deleteByIds(ids);
    }

    @Override
    @Log
    public void add(Emp emp) {
        emp.setCreateTime(LocalDateTime.now());
        emp.setUpdateTime(LocalDateTime.now());
        empMapper.add(emp);
    }

    @Override
    @Log
    public Emp findById(Integer id) {
        return empMapper.findById(id);
    }

    @Override
    @Log
    public void update(Emp emp) {
        emp.setUpdateTime(LocalDateTime.now());
        empMapper.update(emp);
    }

    @Override
    public Emp login(Emp emp) {
        return empMapper.getUserByNameAndPassword(emp);
    }
}
